#include "DGLE.h"

using namespace DGLE;

DGLE_DYNAMIC_FUNC // Include GetEngine and FreeEngine functions to load engine library at runtime.

static const char appCaption[] = "$projectname$";

#ifdef _DEBUG
#	define DLL_PATH "..\\..\\..\\..\\bin\\windows\\DGLE.dll"
#else
#	define DLL_PATH "..\\..\\DGLE.dll"
#endif

#define SCREEN_WIDTH	320u
#define SCREEN_HEIGHT	240u

// pointers to engine classes
IEngineCore *pEngineCore;
IInput *pInput;

// pointers to engine objects
IBitmapFont *pFont;

void DGLE_API Init(void *pParameter)
{
	// You may load any application data here and get engine subsystems.
	
	pEngineCore->GetSubSystem(ESS_INPUT, (IEngineSubSystem *&)pInput);

	IResourceManager *p_res_man;
	pEngineCore->GetSubSystem(ESS_RESOURCE_MANAGER, (IEngineSubSystem *&)p_res_man);

	p_res_man->GetDefaultResource(EOT_BITMAP_FONT, (IEngineBaseObject *&)pFont); // getting default font
}

void DGLE_API Free(void *pParameter)
{
	// You may free application data here.

}

void DGLE_API Update(void *pParameter)
{
	// Application update routine put your logic here.

	bool is_pressed;
	
	pInput->GetKey(KEY_ESCAPE, is_pressed);

	if (is_pressed)
		pEngineCore->QuitEngine(); // exit engine main loop
}

void DGLE_API Render(void *pParameter)
{
	// Frame drawing routine.

	uint width, height;
	
	// render text at the center of the screen
	pFont->GetTextDimensions(appCaption, width, height);
	pFont->Draw2DSimple((SCREEN_WIDTH - width) / 2, (SCREEN_HEIGHT - height) / 2, appCaption, ColorWhite());
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	// Main application entry point.

	if (GetEngine(DLL_PATH, pEngineCore)) // load engine library
	{
		pEngineCore->ConsoleVisible(true); // show engine console (you can use "~" key to show it in any application)

		// engine initialization
		if (SUCCEEDED(pEngineCore->InitializeEngine(NULL, appCaption, TEngineWindow(SCREEN_WIDTH, SCREEN_HEIGHT, false))))
		{
			// register engine callbacks
			pEngineCore->AddProcedure(EPT_INIT,	&Init);
			pEngineCore->AddProcedure(EPT_FREE,	&Free);
			pEngineCore->AddProcedure(EPT_UPDATE, &Update);
			pEngineCore->AddProcedure(EPT_RENDER, &Render);

			pEngineCore->StartEngine(); // start engine main loop
		}

		FreeEngine(); // unload engine library
	}
	else
		MessageBox(NULL, "Couldn't load \"" DLL_PATH "\"!", appCaption, MB_OK | MB_ICONERROR | MB_SETFOREGROUND);

	return 0;
}